import React from "react";
import { createRoot } from "react-dom/client";
import { RakatApp } from "../src/components/rakat-app";
import "../src/styles.css";

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <RakatApp />
  </React.StrictMode>,
);
