import type { Cue } from "@/lib/rakat";

let audio: AudioContext | null = null;
let wake: WakeLockSentinel | null = null;

type RakatNativeBridge = {
  hasProximitySensor?: () => boolean;
  startProximity?: () => boolean;
  stopProximity?: () => void;
  setKeepScreenOn?: (enabled: boolean) => void;
};

declare global {
  interface Window {
    RakatNative?: RakatNativeBridge;
  }
}

function context(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const Ctor =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;
  if (!audio) audio = new Ctor();
  if (audio.state === "suspended") void audio.resume();
  return audio;
}

export function unlockAudio() {
  context();
}

function tone(freq: number, duration: number, peak: number) {
  const ctx = context();
  if (!ctx) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(freq, now);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(peak, now + 0.02);
  gain.gain.setValueAtTime(peak, now + Math.max(0.03, duration - 0.12));
  gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + duration + 0.02);
}

export function playCue(cue: Cue, opts: { sound: boolean; vibrate: boolean }) {
  if (cue === "none") return;
  if (opts.vibrate && typeof navigator !== "undefined" && navigator.vibrate) {
    if (cue === "tick") navigator.vibrate(18);
    else if (cue === "short") navigator.vibrate(120);
    else navigator.vibrate(1700);
  }
  if (!opts.sound || cue === "tick") return;
  if (cue === "short") tone(988, 0.18, 0.22);
  else tone(494, 1.85, 0.2);
}

export async function acquireWakeLock() {
  if (typeof window !== "undefined" && window.RakatNative?.setKeepScreenOn) {
    window.RakatNative.setKeepScreenOn(true);
    return;
  }
  if (typeof navigator === "undefined" || !("wakeLock" in navigator)) return;
  try {
    wake = await navigator.wakeLock.request("screen");
  } catch {
    wake = null;
  }
}

export async function releaseWakeLock() {
  if (typeof window !== "undefined" && window.RakatNative?.setKeepScreenOn) {
    window.RakatNative.setKeepScreenOn(false);
  }
  try {
    await wake?.release();
  } catch {
    /* already released */
  }
  wake = null;
}

type SensorLike = {
  near?: boolean;
  start: () => void;
  stop: () => void;
  addEventListener: (type: string, fn: () => void) => void;
};

export function proximityAvailable(): boolean {
  if (typeof window === "undefined") return false;
  if (window.RakatNative?.hasProximitySensor) {
    try {
      return window.RakatNative.hasProximitySensor();
    } catch {
      return false;
    }
  }
  return "ProximitySensor" in window || "onuserproximity" in window || "ondeviceproximity" in window;
}

export function watchProximity(onNear: () => void): () => void {
  if (typeof window !== "undefined" && window.RakatNative?.startProximity) {
    let prev: boolean | null = null;
    const onNative = (event: Event) => {
      const near = Boolean((event as CustomEvent<{ near?: boolean }>).detail?.near);
      if (near && prev === false) onNear();
      prev = near;
    };
    window.addEventListener("rakatproximity", onNative);
    try {
      window.RakatNative.startProximity();
    } catch {
      /* native sensor unavailable */
    }
    return () => {
      window.removeEventListener("rakatproximity", onNative);
      try {
        window.RakatNative?.stopProximity?.();
      } catch {
        /* sensor already stopped */
      }
    };
  }

  let prev: boolean | null = null;
  const stops: Array<() => void> = [];
  const edge = (near: boolean) => {
    if (near && prev === false) onNear();
    prev = near;
  };

  const onUser = (event: Event) => {
    edge(Boolean((event as Event & { near?: boolean }).near));
  };
  window.addEventListener("userproximity", onUser);
  stops.push(() => window.removeEventListener("userproximity", onUser));

  const onDevice = (event: Event) => {
    const value = (event as Event & { value?: number }).value;
    if (typeof value === "number") edge(value < 5);
  };
  window.addEventListener("deviceproximity", onDevice);
  stops.push(() => window.removeEventListener("deviceproximity", onDevice));

  const Sensor = (window as unknown as { ProximitySensor?: new () => SensorLike }).ProximitySensor;
  if (Sensor) {
    try {
      const sensor = new Sensor();
      sensor.addEventListener("reading", () => edge(Boolean(sensor.near)));
      sensor.start();
      stops.push(() => {
        try {
          sensor.stop();
        } catch {
          /* already stopped */
        }
      });
    } catch {
      /* permission or unsupported */
    }
  }

  return () => {
    for (const stop of stops) stop();
  };
}
