package com.rakatshomar

import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity(), SensorEventListener {
    private lateinit var webView: WebView
    private lateinit var sensorManager: SensorManager
    private var proximitySensor: Sensor? = null
    private var listening = false
    private var proximityRequested = false
    private var lastNear: Boolean? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(12, 20, 18)
        window.navigationBarColor = android.graphics.Color.rgb(12, 20, 18)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(12, 20, 18))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.mediaPlaybackRequiresUserGesture = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(NativeBridge(), "RakatNative")
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/public/index.html")
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun hasProximitySensor(): Boolean = proximitySensor != null

        @JavascriptInterface
        fun startProximity(): Boolean {
            if (proximitySensor == null) return false
            proximityRequested = true
            return startSensorListening()
        }

        @JavascriptInterface
        fun stopProximity() {
            proximityRequested = false
            stopSensorListening()
        }

        @JavascriptInterface
        fun setKeepScreenOn(enabled: Boolean) {
            runOnUiThread {
                if (enabled) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_PROXIMITY) return
        val maxRange = event.sensor.maximumRange
        val near = event.values.firstOrNull()?.let { it < maxRange } ?: false
        if (lastNear == near) return
        lastNear = near
        webView.post {
            webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('rakatproximity',{detail:{near:$near}}));",
                null,
            )
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun startSensorListening(): Boolean {
        val sensor = proximitySensor ?: return false
        if (listening) return true
        lastNear = null
        listening = sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        return listening
    }

    private fun stopSensorListening() {
        if (listening) sensorManager.unregisterListener(this)
        listening = false
        lastNear = null
    }

    override fun onResume() {
        super.onResume()
        if (proximityRequested) startSensorListening()
    }

    override fun onPause() {
        stopSensorListening()
        super.onPause()
    }

    override fun onDestroy() {
        proximityRequested = false
        sensorManager.unregisterListener(this)
        webView.removeJavascriptInterface("RakatNative")
        webView.destroy()
        super.onDestroy()
    }
}
