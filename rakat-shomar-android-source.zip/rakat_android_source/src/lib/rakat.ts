export type PrayerId =
  | "fajr"
  | "dhuhr"
  | "asr"
  | "maghrib"
  | "isha"
  | "witr"
  | "custom";

export type Prayer = {
  id: Exclude<PrayerId, "custom">;
  name: string;
  rakats: number;
};

export const PRAYERS: Prayer[] = [
  { id: "fajr", name: "صبح", rakats: 2 },
  { id: "dhuhr", name: "ظهر", rakats: 4 },
  { id: "asr", name: "عصر", rakats: 4 },
  { id: "maghrib", name: "مغرب", rakats: 3 },
  { id: "isha", name: "عشا", rakats: 4 },
  { id: "witr", name: "وتر", rakats: 1 },
];

const FA = "۰۱۲۳۴۵۶۷۸۹";

export function fa(value: number | string): string {
  return String(value).replace(/\d/g, (d) => FA[Number(d)] ?? d);
}

export type Phase = "pick" | "pray" | "settle" | "done";
export type SujudCount = 0 | 1 | 2;
export type Cue = "none" | "tick" | "short" | "long";

export type Session = {
  phase: Phase;
  name: string;
  total: number;
  rakat: number;
  sujud: SujudCount;
  banner: "tashahhud" | null;
};

export function emptySession(): Session {
  return { phase: "pick", name: "", total: 0, rakat: 1, sujud: 0, banner: null };
}

export function startSession(name: string, total: number): Session {
  return { phase: "pray", name, total, rakat: 1, sujud: 0, banner: null };
}

export function registerSujud(session: Session): { session: Session; cue: Cue } {
  if (session.phase !== "pray") return { session, cue: "none" };

  if (session.sujud === 0) {
    return { session: { ...session, sujud: 1, banner: null }, cue: "tick" };
  }

  if (session.rakat >= session.total) {
    const finalCue: Cue = session.rakat === 2 ? "short" : "long";
    return {
      session: { ...session, sujud: 2, phase: "done", banner: session.rakat === 2 ? "tashahhud" : null },
      cue: finalCue,
    };
  }

  const middle = session.rakat === 2 && session.total > 2;
  return {
    session: {
      ...session,
      sujud: 2,
      phase: "settle",
      banner: middle ? "tashahhud" : null,
    },
    cue: middle ? "short" : "tick",
  };
}

export function advanceSettled(session: Session): Session {
  if (session.phase !== "settle") return session;
  return { ...session, phase: "pray", rakat: session.rakat + 1, sujud: 0 };
}

export function undoSujud(session: Session): Session {
  if (session.phase === "pick") return session;
  if (session.phase === "done" || session.phase === "settle") {
    return { ...session, phase: "pray", sujud: 1, banner: null };
  }
  if (session.sujud === 1) return { ...session, sujud: 0, banner: null };
  if (session.rakat > 1) {
    return { ...session, rakat: session.rakat - 1, sujud: 1, banner: null };
  }
  return session;
}

export function canUndo(session: Session): boolean {
  if (session.phase === "done" || session.phase === "settle") return true;
  if (session.phase !== "pray") return false;
  return session.sujud > 0 || session.rakat > 1;
}

export function beepPlan(total: number): string {
  if (total === 2) return "پایان رکعت دوم: بوق کوتاه برای تشهد؛ سپس بوق ممتد برای پایان نماز.";
  if (total < 2) return "پایان نماز با بوق ممتد اعلام می‌شود.";
  return "پایان رکعت دوم بوق کوتاه؛ پایان نماز بوق ممتد.";
}

export type InputMode = "touch" | "near";

export type Settings = {
  sound: boolean;
  vibrate: boolean;
  input: InputMode;
  customRakats: number;
  witrRakats: 1 | 3;
  prayerId: PrayerId;
  fontScale: number;
};

export const DEFAULT_SETTINGS: Settings = {
  sound: true,
  vibrate: true,
  input: "touch",
  customRakats: 2,
  witrRakats: 1,
  prayerId: "dhuhr",
  fontScale: 1,
};

const SETTINGS_KEY = "rakat-shomar-settings";
const SESSION_KEY = "rakat-shomar-session";

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<Settings>;
    const custom = Number(parsed.customRakats);
    const prayerId = PRAYERS.some((p) => p.id === parsed.prayerId) || parsed.prayerId === "custom"
      ? (parsed.prayerId as PrayerId)
      : DEFAULT_SETTINGS.prayerId;
    return {
      sound: parsed.sound !== false,
      vibrate: parsed.vibrate !== false,
      input: parsed.input === "near" ? "near" : "touch",
      customRakats: Number.isFinite(custom) ? Math.min(20, Math.max(1, Math.round(custom))) : 2,
      witrRakats: parsed.witrRakats === 3 ? 3 : 1,
      prayerId,
      fontScale: Number.isFinite(Number(parsed.fontScale))
        ? Math.min(1.35, Math.max(0.85, Number(parsed.fontScale)))
        : 1,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: Settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export function loadSession(): Session | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Session;
    if (!parsed || (parsed.phase !== "pray" && parsed.phase !== "settle" && parsed.phase !== "done")) {
      return null;
    }
    if (!parsed.name || !parsed.total) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveSession(session: Session) {
  if (session.phase === "pick") localStorage.removeItem(SESSION_KEY);
  else localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}
