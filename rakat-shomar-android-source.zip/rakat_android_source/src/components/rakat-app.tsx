import { useEffect, useRef, useState } from "react";
import {
  Check,
  Hand,
  Minus,
  Moon,
  Plus,
  Radar,
  Star,
  Sun,
  SunMedium,
  Sunrise,
  Sunset,
  Undo2,
  Vibrate,
  Volume2,
  VolumeX,
  type LucideIcon,
} from "lucide-react";
import {
  acquireWakeLock,
  playCue,
  proximityAvailable,
  releaseWakeLock,
  unlockAudio,
  watchProximity,
} from "@/lib/feedback";
import {
  DEFAULT_SETTINGS,
  PRAYERS,
  advanceSettled,
  beepPlan,
  canUndo,
  emptySession,
  fa,
  loadSession,
  loadSettings,
  registerSujud,
  saveSession,
  saveSettings,
  startSession,
  undoSujud,
  type PrayerId,
  type Session,
  type Settings,
} from "@/lib/rakat";

const ICONS: Record<string, LucideIcon> = {
  fajr: Sunrise,
  dhuhr: Sun,
  asr: SunMedium,
  maghrib: Sunset,
  isha: Moon,
  witr: Star,
};

const MIN_GAP = 320;
const SETTLE_MS = 760;

function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function RakatApp() {
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [session, setSession] = useState<Session>(emptySession);
  const [booted, setBooted] = useState(false);
  const [nearOk, setNearOk] = useState(false);
  const [pulse, setPulse] = useState<"short" | "long" | null>(null);
  const lastFire = useRef(0);
  const endCueTimer = useRef<number | undefined>(undefined);
  const countRef = useRef<() => void>(() => {});
  const sessionRef = useRef(session);
  sessionRef.current = session;

  useEffect(() => {
    const saved = loadSession();
    if (saved) setSession(saved);
    setSettings(loadSettings());
    setNearOk(proximityAvailable());
    setBooted(true);
  }, []);

  useEffect(() => {
    if (!booted) return;
    saveSettings(settings);
  }, [settings, booted]);

  useEffect(() => {
    document.documentElement.style.fontSize = `${settings.fontScale * 16}px`;
  }, [settings.fontScale]);

  useEffect(() => {
    if (!booted) return;
    saveSession(session);
  }, [session, booted]);

  useEffect(() => {
    if (session.phase !== "settle") return;
    const timer = window.setTimeout(() => {
      setSession((current) => advanceSettled(current));
    }, SETTLE_MS);
    return () => window.clearTimeout(timer);
  }, [session.phase, session.rakat]);

  useEffect(() => {
    if (session.banner !== "tashahhud") return;
    const timer = window.setTimeout(() => {
      setSession((current) =>
        current.banner === "tashahhud" ? { ...current, banner: null } : current,
      );
    }, 2200);
    return () => window.clearTimeout(timer);
  }, [session.banner, session.rakat]);

  useEffect(() => {
    if (!pulse) return;
    const timer = window.setTimeout(() => setPulse(null), pulse === "long" ? 1900 : 420);
    return () => window.clearTimeout(timer);
  }, [pulse]);

  useEffect(() => {
    const praying = session.phase !== "pick";
    if (!praying) {
      void releaseWakeLock();
      return;
    }
    void acquireWakeLock();
    const onVis = () => {
      if (document.visibilityState === "visible") void acquireWakeLock();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [session.phase]);

  useEffect(() => {
    if (!booted || settings.input !== "near" || session.phase === "pick") return;
    return watchProximity(() => countRef.current());
  }, [booted, settings.input, session.phase === "pick"]);

  const totalFor = (id: PrayerId) => {
    if (id === "custom") return settings.customRakats;
    if (id === "witr") return settings.witrRakats;
    return PRAYERS.find((prayer) => prayer.id === id)?.rakats ?? 4;
  };

  const nameFor = (id: PrayerId) => {
    if (id === "custom") return "دلخواه";
    return PRAYERS.find((prayer) => prayer.id === id)?.name ?? "";
  };

  function commit(next: Session) {
    sessionRef.current = next;
    setSession(next);
  }

  function count() {
    if (sessionRef.current.phase !== "pray") return;
    const now = Date.now();
    if (now - lastFire.current < MIN_GAP) return;
    lastFire.current = now;
    unlockAudio();
    const next = registerSujud(sessionRef.current);
    commit(next.session);
    if (next.cue === "short" || next.cue === "long") setPulse(next.cue);
    playCue(next.cue, { sound: settings.sound, vibrate: settings.vibrate });
    if (next.session.phase === "done" && next.cue === "short") {
      if (endCueTimer.current !== undefined) window.clearTimeout(endCueTimer.current);
      endCueTimer.current = window.setTimeout(() => {
        setPulse("long");
        playCue("long", { sound: settings.sound, vibrate: settings.vibrate });
        endCueTimer.current = undefined;
      }, 2200);
    }
  }

  countRef.current = count;

  function undo() {
    if (endCueTimer.current !== undefined) window.clearTimeout(endCueTimer.current);
    endCueTimer.current = undefined;
    lastFire.current = Date.now();
    commit(undoSujud(sessionRef.current));
  }

  function begin() {
    if (endCueTimer.current !== undefined) window.clearTimeout(endCueTimer.current);
    endCueTimer.current = undefined;
    unlockAudio();
    lastFire.current = 0;
    setPulse(null);
    commit(startSession(nameFor(settings.prayerId), totalFor(settings.prayerId)));
  }

  function backToList() {
    if (endCueTimer.current !== undefined) window.clearTimeout(endCueTimer.current);
    endCueTimer.current = undefined;
    setPulse(null);
    commit(emptySession());
  }

  function again() {
    if (endCueTimer.current !== undefined) window.clearTimeout(endCueTimer.current);
    endCueTimer.current = undefined;
    unlockAudio();
    lastFire.current = 0;
    setPulse(null);
    commit(startSession(session.name, session.total));
  }

  function previewBeeps() {
    unlockAudio();
    playCue("short", { sound: true, vibrate: settings.vibrate });
    window.setTimeout(() => {
      playCue("long", { sound: true, vibrate: settings.vibrate });
    }, 700);
  }

  const selectedTotal = totalFor(settings.prayerId);

  return (
    <div
      className={cx(
        "app-shell mx-auto flex h-dvh w-full max-w-md flex-col bg-bg text-fg",
        pulse === "long" && "pulse-long",
        pulse === "short" && "pulse-short",
      )}
      data-phase={session.phase}
    >
      {session.phase === "pick" ? (
        <Picker
          settings={settings}
          nearOk={nearOk}
          total={selectedTotal}
          onSelect={(prayerId) => setSettings((s) => ({ ...s, prayerId }))}
          onCustom={(customRakats) => setSettings((s) => ({ ...s, customRakats, prayerId: "custom" }))}
          onWitr={(witrRakats) => setSettings((s) => ({ ...s, witrRakats }))}
          onInput={(input) => setSettings((s) => ({ ...s, input }))}
          onSound={() => setSettings((s) => ({ ...s, sound: !s.sound }))}
          onVibrate={() => setSettings((s) => ({ ...s, vibrate: !s.vibrate }))}
          onFontScale={(fontScale) => setSettings((s) => ({ ...s, fontScale }))}
          onPreview={previewBeeps}
          onStart={begin}
        />
      ) : (
        <Counter
          session={session}
          input={settings.input}
          nearAvailable={nearOk}
          sound={settings.sound}
          onCount={count}
          onUndo={undo}
          onBack={backToList}
          onAgain={again}
          onSound={() => setSettings((s) => ({ ...s, sound: !s.sound }))}
        />
      )}
    </div>
  );
}

function Picker({
  settings,
  nearOk,
  total,
  onSelect,
  onCustom,
  onWitr,
  onInput,
  onSound,
  onVibrate,
  onFontScale,
  onPreview,
  onStart,
}: {
  settings: Settings;
  nearOk: boolean;
  total: number;
  onSelect: (id: PrayerId) => void;
  onCustom: (n: number) => void;
  onWitr: (n: 1 | 3) => void;
  onInput: (mode: Settings["input"]) => void;
  onSound: () => void;
  onVibrate: () => void;
  onFontScale: (scale: number) => void;
  onPreview: () => void;
  onStart: () => void;
}) {
  const name = settings.prayerId === "custom" ? "دلخواه" : PRAYERS.find((p) => p.id === settings.prayerId)?.name;

  return (
    <div className="flex h-full flex-col overflow-y-auto px-5 pt-6 pb-5">
      <header className="mb-5">
        <p className="text-sm text-gold">نماز</p>
        <h1 className="mt-1 text-3xl font-semibold tracking-tight">رکعت‌شمار</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          هر لمس یک سجده است. هر رکعت فقط دو سجده دارد.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-2.5">
        {PRAYERS.map((prayer) => {
          const Icon = ICONS[prayer.id] ?? Sun;
          const selected = settings.prayerId === prayer.id;
          return (
            <button
              key={prayer.id}
              type="button"
              data-testid={`prayer-${prayer.id}`}
              aria-pressed={selected}
              onClick={() => onSelect(prayer.id)}
              className={cx(
                "flex min-h-20 items-center justify-between rounded-card border px-3.5 text-start",
                selected ? "border-gold bg-gold/10" : "border-fg/10 bg-fg/5",
              )}
            >
              <span className="flex items-center gap-2">
                <Icon className={cx("size-5", selected ? "text-gold" : "text-muted")} strokeWidth={1.75} />
                <span className="text-base font-medium">{prayer.name}</span>
              </span>
              <span className={cx("text-2xl font-semibold tabular-nums", selected ? "text-gold" : "text-fg")}>
                {fa(prayer.id === "witr" ? settings.witrRakats : prayer.rakats)}
              </span>
            </button>
          );
        })}
      </div>

      {settings.prayerId === "witr" ? (
        <div className="mt-2.5 rounded-card border border-gold/50 bg-gold/5 px-3.5 py-3">
          <p className="mb-2 text-sm text-muted">تعداد رکعت وتر</p>
          <div className="grid grid-cols-2 gap-2">
            {([1, 3] as const).map((count) => (
              <button
                key={count}
                type="button"
                aria-pressed={settings.witrRakats === count}
                onClick={() => onWitr(count)}
                className={cx(
                  "min-h-11 rounded-xl border text-base font-medium",
                  settings.witrRakats === count ? "border-gold bg-gold/15 text-gold" : "border-fg/10 text-muted",
                )}
              >
                {fa(count)} رکعت
              </button>
            ))}
          </div>
        </div>
      ) : null}

      <div
        className={cx(
          "mt-2.5 flex min-h-16 items-center justify-between rounded-card border px-3.5",
          settings.prayerId === "custom" ? "border-gold bg-gold/10" : "border-fg/10 bg-fg/5",
        )}
      >
        <button type="button" className="text-base font-medium" onClick={() => onCustom(settings.customRakats)}>
          دلخواه
        </button>
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full border border-fg/15 bg-bg"
            aria-label="کم کردن رکعت"
            onClick={() => onCustom(Math.max(1, settings.customRakats - 1))}
          >
            <Minus className="size-4" />
          </button>
          <span className="w-8 text-center text-2xl font-semibold text-gold tabular-nums">
            {fa(settings.customRakats)}
          </span>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full border border-fg/15 bg-bg"
            aria-label="زیاد کردن رکعت"
            onClick={() => onCustom(Math.min(20, settings.customRakats + 1))}
          >
            <Plus className="size-4" />
          </button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <button
          type="button"
          aria-pressed={settings.input === "touch"}
          onClick={() => onInput("touch")}
          className={cx(
            "flex min-h-12 items-center justify-center gap-2 rounded-card border text-sm",
            settings.input === "touch" ? "border-gold text-gold" : "border-fg/10 text-muted",
          )}
        >
          <Hand className="size-4" />
          لمس صفحه
        </button>
        <button
          type="button"
          aria-pressed={settings.input === "near"}
          onClick={() => onInput("near")}
          className={cx(
            "flex min-h-12 items-center justify-center gap-2 rounded-card border text-sm",
            settings.input === "near" ? "border-gold text-gold" : "border-fg/10 text-muted",
          )}
        >
          <Radar className="size-4" />
          سنسور نزدیکی
        </button>
      </div>
      {settings.input === "near" && !nearOk ? (
        <p className="mt-2 text-xs leading-relaxed text-muted">
          این مرورگر سنسور نزدیکی را باز نمی‌کند. لمس صفحه همچنان هر سجده را می‌شمارد.
        </p>
      ) : null}

      <div className="mt-3 flex min-h-12 items-center justify-between rounded-card border border-fg/10 px-3.5">
        <span className="text-sm">اندازه نوشته‌ها</span>
        <div className="flex items-center gap-3">
          <button type="button" aria-label="کوچک کردن نوشته‌ها" disabled={settings.fontScale <= 0.85} onClick={() => onFontScale(Math.max(0.85, Number((settings.fontScale - 0.1).toFixed(2))))} className="flex size-9 items-center justify-center rounded-full border border-fg/15 disabled:opacity-40">−</button>
          <span className="min-w-12 text-center text-sm tabular-nums">{Math.round(settings.fontScale * 100)}٪</span>
          <button type="button" aria-label="بزرگ کردن نوشته‌ها" disabled={settings.fontScale >= 1.35} onClick={() => onFontScale(Math.min(1.35, Number((settings.fontScale + 0.1).toFixed(2))))} className="flex size-9 items-center justify-center rounded-full border border-fg/15 disabled:opacity-40">+</button>
        </div>
      </div>

      <div className="mt-3 flex gap-2">
        <button
          type="button"
          aria-pressed={settings.sound}
          onClick={onSound}
          className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-card border border-fg/10 text-sm"
        >
          {settings.sound ? <Volume2 className="size-4 text-gold" /> : <VolumeX className="size-4" />}
          {settings.sound ? "صدا روشن" : "صدا خاموش"}
        </button>
        <button
          type="button"
          aria-pressed={settings.vibrate}
          onClick={onVibrate}
          className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-card border border-fg/10 text-sm"
        >
          <Vibrate className={cx("size-4", settings.vibrate && "text-gold")} />
          {settings.vibrate ? "لرزش روشن" : "لرزش خاموش"}
        </button>
      </div>

      <div className="mt-4 rounded-card border border-fg/10 px-3.5 py-3">
        <div className="flex items-center justify-between text-sm">
          <span>پایان رکعت دوم</span>
          <span className="h-1.5 w-4 rounded-full bg-gold" />
        </div>
        <div className="mt-2 flex items-center justify-between text-sm">
          <span>پایان نماز</span>
          <span className="h-1.5 w-14 rounded-full bg-gold" />
        </div>
        <button type="button" onClick={onPreview} className="mt-3 text-sm text-gold">
          شنیدن تفاوت بوق‌ها
        </button>
      </div>

      <div className="mt-auto pt-4">
        <p className="mb-3 text-center text-sm text-muted">
          {fa(total)} رکعت · {fa(total * 2)} سجده
          <span className="mt-1 block">{beepPlan(total)}</span>
        </p>
        <button
          type="button"
          data-testid="start"
          onClick={onStart}
          className="flex h-14 w-full items-center justify-center rounded-card bg-gold text-lg font-semibold text-ink"
        >
          شروع نماز {name}
        </button>
      </div>
    </div>
  );
}

function Counter({
  session,
  input,
  nearAvailable,
  sound,
  onCount,
  onUndo,
  onBack,
  onAgain,
  onSound,
}: {
  session: Session;
  input: Settings["input"];
  nearAvailable: boolean;
  sound: boolean;
  onCount: () => void;
  onUndo: () => void;
  onBack: () => void;
  onAgain: () => void;
  onSound: () => void;
}) {
  const done = session.phase === "done";
  const undoable = canUndo(session);
  const status =
    done
      ? `نماز ${session.name} تمام شد`
      : session.banner === "tashahhud"
        ? "تشهد — بوق کوتاه"
        : `رکعت ${fa(session.rakat)} از ${fa(session.total)}`;

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center justify-between px-5 pt-5 pb-2">
        <div>
          <p className="text-sm text-gold">نماز {session.name}</p>
          <p className="text-xs text-muted">{fa(session.total)} رکعت</p>
        </div>
        <button type="button" onClick={onBack} className="min-h-11 px-2 text-sm text-muted">
          نمازها
        </button>
      </header>

      <div className="flex h-12 items-center justify-center px-5">
        {done ? (
          <p data-testid="banner" className="text-sm font-medium text-gold">
            تشهد آخر و سلام — بوق ممتد پس از یادآوری
          </p>
        ) : session.banner === "tashahhud" ? (
          <p data-testid="banner" className="text-sm font-medium text-gold">
            پایان رکعت دوم — تشهد، بعد بلند شوید
          </p>
        ) : (
          <p data-testid="banner" className="text-sm text-muted">
            {input === "near" && nearAvailable ? "هر بار نزدیک شدن به حسگر = یک سجده" : "هر لمس = یک سجده"}
          </p>
        )}
      </div>

      <button
        type="button"
        data-testid="tap-zone"
        className="tap-zone flex min-h-0 flex-1 flex-col items-center justify-center px-5"
        onClick={input === "touch" || !nearAvailable ? onCount : undefined}
        onContextMenu={(event) => event.preventDefault()}
        aria-label="ثبت سجده"
      >
        <span className="text-sm tracking-widest text-muted">رکعت</span>
        <span data-testid="rakat-count" className="rakat-num mt-2 text-gold">
          {fa(session.rakat)}
        </span>
        <span data-testid="status" className="mt-3 text-base text-fg" aria-live="polite">
          {status}
        </span>

        <div className="mt-8 grid w-full grid-cols-2 gap-3">
          <SujudCard label="سجده اول" filled={session.sujud >= 1} next={session.sujud === 0 && !done} />
          <SujudCard label="سجده دوم" filled={session.sujud >= 2} next={session.sujud === 1 && !done} />
        </div>
        <p data-testid="sujud-count" className="mt-3 text-sm text-muted">
          {fa(session.sujud)} از ۲
        </p>
      </button>

      <footer className="grid grid-cols-3 gap-2 px-4 pt-2 pb-4">
        {done ? (
          <>
            <button
              type="button"
              onClick={onBack}
              className="col-span-1 flex h-12 items-center justify-center rounded-card border border-fg/10 text-sm"
            >
              نماز دیگر
            </button>
            <button
              type="button"
              onClick={onAgain}
              className="col-span-2 flex h-12 items-center justify-center rounded-card bg-gold text-base font-semibold text-ink"
            >
              دوباره همین نماز
            </button>
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={onUndo}
              disabled={!undoable}
              className="flex h-12 items-center justify-center gap-1 rounded-card border border-fg/10 text-sm disabled:opacity-40"
            >
              <Undo2 className="size-4" />
              عقب
            </button>
            <p className="flex items-center justify-center text-center text-xs leading-snug text-muted">
              دو سجده، بعد رکعت بعد
            </p>
            <button
              type="button"
              onClick={onSound}
              className="flex h-12 items-center justify-center gap-1 rounded-card border border-fg/10 text-sm"
              aria-label={sound ? "قطع صدا" : "روشن کردن صدا"}
            >
              {sound ? <Volume2 className="size-4 text-gold" /> : <VolumeX className="size-4" />}
              صدا
            </button>
          </>
        )}
      </footer>
    </div>
  );
}

function SujudCard({ label, filled, next }: { label: string; filled: boolean; next: boolean }) {
  return (
    <div
      className={cx(
        "sujud-card flex min-h-24 flex-col items-center justify-center gap-2 rounded-card border",
        filled ? "border-gold bg-gold text-ink" : next ? "border-gold bg-transparent text-fg" : "border-fg/10 bg-fg/5 text-muted",
      )}
    >
      <span className="text-sm font-medium">{label}</span>
      <span
        className={cx(
          "flex size-6 items-center justify-center rounded-full border",
          filled ? "border-ink bg-ink text-gold" : "border-current",
        )}
        aria-hidden="true"
      >
        {filled ? <Check className="size-3.5" strokeWidth={2.5} /> : null}
      </span>
    </div>
  );
}
