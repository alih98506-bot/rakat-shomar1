import test from "node:test";
import assert from "node:assert/strict";
import {
  DEFAULT_SETTINGS,
  advanceSettled,
  registerSujud,
  startSession,
} from "./rakat.ts";

function finish(total: number) {
  let session = startSession("آزمایشی", total);
  const cues: string[] = [];
  while (session.phase !== "done") {
    const result = registerSujud(session);
    session = result.session;
    cues.push(result.cue);
    if (session.phase === "settle") session = advanceSettled(session);
  }
  return { session, cues };
}

test("default Witr setting is one rakah and supports three", () => {
  assert.equal(DEFAULT_SETTINGS.witrRakats, 1);
});

test("two-rakah prayer gives tashahhud reminder before the end cue", () => {
  const { session, cues } = finish(2);
  assert.equal(session.phase, "done");
  assert.equal(session.rakat, 2);
  assert.equal(session.sujud, 2);
  assert.equal(cues.at(-1), "short");
});

test("longer prayer reminds at the end of rakah two and finishes with long cue", () => {
  const { session, cues } = finish(4);
  assert.equal(session.rakat, 4);
  assert.equal(session.sujud, 2);
  assert.equal(cues.filter((cue) => cue === "short").length, 1);
  assert.equal(cues.at(-1), "long");
});

test("one-rakah prayer finishes with long cue", () => {
  const { session, cues } = finish(1);
  assert.equal(session.rakat, 1);
  assert.equal(cues.at(-1), "long");
});
