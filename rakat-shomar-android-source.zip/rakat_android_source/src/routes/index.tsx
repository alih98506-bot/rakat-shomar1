import { createFileRoute } from "@tanstack/react-router";
import { RakatApp } from "@/components/rakat-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <RakatApp />;
}
